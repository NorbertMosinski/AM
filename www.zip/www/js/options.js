//Tolerance by finding the beginning and end of the labirynth. 0.1 = 10% of image height
const OPT_MAZE_INITTOLERANCE = 0.1;
//Number of steps to be done when moving the person
const OPT_GAME_STEPS = 9;
//Time limit for each level (min) 	
const OPT_GAME_TIMELIMIT = 3.00;
//Person size x*x in px (odd number)
const OPT_PERSON_SIZE = 9;
//Canvas width
const OPT_CANVAS_WIDTH = 358;
//Canvas height
const OPT_CANVAS_HEIGHT = 615;
//More performance, less quality
const OPT_PERFORMANCEMODE = false;

//Top direction
const CONST_POS_TOP = new Position(0, -1);
//Bot direction
const CONST_POS_BOT = new Position(0, 1);
//Left direction
const CONST_POS_LEFT = new Position(-1, 0);
//Right direction
const CONST_POS_RIGHT = new Position(1, 0);
//Top-left direction
const CONST_POS_TOPLEFT = new Position(-1, -1);
//Top-right direction
const CONST_POS_TOPRIGHT = new Position(1, -1);
//Bot-left direction
const CONST_POS_BOTLEFT = new Position(-1, 1);
//Bot-right direction
const CONST_POS_BOTRIGHT = new Position(1, 1);
//White color
const CONST_COL_WHITE = new Color(255, 255, 255);
//Black color
const CONST_COL_BLACK = new Color(0, 0, 0);