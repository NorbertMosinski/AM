{
	"name": "my-project-name",
	"version": "0.1.0",
	"devDependencies":
	{
		"grunt": "~0.4.5",
		
	}
}
